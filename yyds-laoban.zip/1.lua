配置文件中的区域名称
所有涉及职业名称的地方（biker -> police）
所有涉及动作名称的地方（biker_actions -> police_actions）
所有涉及函数名称的地方（Openbiker -> Openpolice）
society名称的修改（society_biker -> society_police）