RegisterNetEvent('esx_society:openBossMenu')
AddEventHandler('esx_society:openBossMenu', function(society, close, options)
    ESX.TriggerServerCallback('esx_society:getSociety', function(data)
        if data then
            options = options or {}
            options.withdraw = true
            options.deposit = true
            options.wash = true
            options.employees = true
            options.grades = true

            TriggerEvent('esx_society:openBossMenu', society, close, options)
        end
    end, society)
end)



Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        local playerData = ESX.GetPlayerData()
        local jobName = playerData.job.name
        
        
        if Config.BossMenus[jobName] and Config.AllowedJobs[jobName] then
            local bossMenu = Config.BossMenus[jobName]
            local distance = #(playerCoords - bossMenu.pos)
            
            if distance < 2.0 and playerData.job.grade >= Config.MinimumGrade then
                ESX.ShowHelpNotification('按 ~INPUT_CONTEXT~ 打开' .. bossMenu.label)
                if IsControlJustReleased(0, 38) then -- E 键
                    local societyName = 'society_' .. jobName
                    TriggerEvent('esx_society:openBossMenu', societyName, function(data, menu)
                        menu.close()
                    end)
                end
            end
        end
    end
end)


RegisterCommand('openboss', function()
    local playerData = ESX.GetPlayerData()
    local jobName = playerData.job.name
    
    if Config.AllowedJobs[jobName] and playerData.job.grade >= Config.MinimumGrade then
        local societyName = 'society_' .. jobName  --society_police那个可以改成需要多的职业名
        TriggerEvent('esx_society:openBossMenu', societyName, function(data, menu)
            menu.close()
        end)
    else
        ESX.ShowNotification('你没有权限使用此命令')
    end
end)

function OpenpoliceActionsMenu()   --police要改成需要改的职业名字
    local elements = {
        {label = _U('deposit_stock'), value = 'put_stock'},
        {label = _U('take_stock'), value = 'get_stock'}
    }

    if Config.EnablePlayerManagement and ESX.PlayerData.job and ESX.PlayerData.job.grade_name == 'boss' then
        table.insert(elements, {
            label = _U('boss_actions'),
            value = 'boss_actions'
        })
    end

    ESX.UI.Menu.CloseAll()

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'police_actions', {   --police_actions那个可以改成需要多的职业名
        title = _U('police'),          --police那个可以改成需要多的职业名
        align = 'top-left',
        elements = elements
    }, function(data, menu)
        if Config.OxInventory and (data.current.value == 'put_stock' or data.current.value == 'get_stock') then
            exports.ox_inventory:openInventory('stash', 'society_police')  --society_police那个可以改成需要多的职业名
            return ESX.UI.Menu.CloseAll()
        elseif data.current.value == 'put_stock' then
            OpenPutStocksMenu()
        elseif data.current.value == 'get_stock' then
            OpenGetStocksMenu()
        elseif data.current.value == 'boss_actions' then
            TriggerEvent('esx_society:openBossMenu', 'police', function(data, menu)
                menu.close()
            end)
        end
    end, function(data, menu)
        menu.close()
        CurrentAction = 'police_actions_menu'  --police_actions_menu那个可以改成需要多的职业名
        CurrentActionMsg = _U('press_to_open')
        CurrentActionData = {}
    end)
end


CreateThread(function()
    while true do
        local sleep = 1500
        if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then  --police那个可以改成需要多的职业名
            local coords = GetEntityCoords(PlayerPedId())
            local isInMarker, currentZone = false

            for k, v in pairs(Config.Zones) do
                local distance = #(coords - vector3(v.Pos.x, v.Pos.y, v.Pos.z))

                if v.Type ~= -1 and distance < Config.DrawDistance then
                    sleep = 0
                    DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
                        v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 100, false, false, 2, v.Rotate, nil, nil, false)
                end

                if distance < v.Size.x then
                    isInMarker, currentZone = true, k
                end
            end

            if (isInMarker and not HasAlreadyEnteredMarker) or (isInMarker and LastZone ~= currentZone) then
                HasAlreadyEnteredMarker, LastZone = true, currentZone
                TriggerEvent('esx_biker:hasEnteredMarker', currentZone)
            end

            if not isInMarker and HasAlreadyEnteredMarker then
                HasAlreadyEnteredMarker = false
                TriggerEvent('esx_biker:hasExitedMarker', LastZone)
            end
        end
        Wait(sleep)
    end
end)


AddEventHandler('esx_biker:hasEnteredMarker', function(zone)
    if zone == 'policeActions' then
        CurrentAction = 'police_actions_menu'  --police_actions_menu那个可以改成需要多的职业名
        CurrentActionMsg = _U('press_to_open')
        CurrentActionData = {}
    elseif zone == 'Cloakroom' then
        CurrentAction = 'cloakroom'
        CurrentActionMsg = _U('cloakroom_prompt')
        CurrentActionData = {}
    end
end)

CreateThread(function()
    while true do
        local sleep = 1500
        if CurrentAction and not ESX.PlayerData.dead then
            sleep = 0
            ESX.ShowHelpNotification(CurrentActionMsg)

            if IsControlJustReleased(0, 38) and ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then  --police那个可以改成需要多的职业名
                if CurrentAction == 'police_actions_menu' then  --police_actions_menu那个可以改成需要多的职业名
                    OpenpoliceActionsMenu()
                elseif CurrentAction == 'cloakroom' then
                    OpenCloakroom()
                elseif CurrentAction == 'delete_vehicle' then 
                    DeleteJobVehicle()
                end

                CurrentAction = nil
            end
        end
        Wait(sleep)
    end
end)