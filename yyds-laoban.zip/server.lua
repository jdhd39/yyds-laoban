-- 注册公户事件
ESX.RegisterServerCallback('esx_society:getSociety', function(source, cb, societyName)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    -- 检查玩家是否属于该公会且职位等级足够
    if xPlayer.job.name == societyName:gsub('society_', '') and xPlayer.job.grade >= 3 then -- 3为需要的最低等级
        local society = GetSociety(societyName)
        cb(society)
    else
        cb(nil)
    end
end)