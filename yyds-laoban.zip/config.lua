Config = {}

Config.EnablePlayerManagement = true  -- 是否启用玩家管理

Config.Zones = {
    policeActions = {       --警察police那个可以改成需要多的职业名
        Pos   = {x = -1677.4599609375,  y = 450.6199951171875, z = 135.10000610351565-0.9},
        Size  = {x = 2.0, y = 2.0, z = 1.0},
        Color = {r = 204, g = 204, b = 0},
        Type  = 1, Rotate = false
    },
    -- 可以添加更多区域
}

Config.DrawDistance = 10.0  -- 标记点显示距离